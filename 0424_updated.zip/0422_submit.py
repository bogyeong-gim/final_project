
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import pygame

BG = "#FFFFFF"
ACCENT = "#9B6F3A"
TEXT_DARK = "#5C3D2E"
TEXT_MID = "#7A5C44"
TEXT_GRAY = "#AAAAAA"
BTN_RED = "#D4A5A5"

OUTFIT_DATA = {
    ("School",   "Warm", "hot"):  ("Red Shirt",               "Short Dark Denim Shorts"),
    ("School",   "Warm", "warm"): ("Green Sweater",           "Brown Pants"),
    ("School",   "Warm", "cool"): ("Pink Sweatshirt",         "Grey Sweatpants"),
    ("School",   "Warm", "cold"): ("Brown Butterfly Cardigan","Black Sweatpants"),
    ("School",   "Cool", "hot"):  ("Mint Strawberry Shirt",   "Light Denim Shorts"),
    ("School",   "Cool", "warm"): ("Pink Striped Shirt",      "Light Denim Bermuda Shorts"),
    ("School",   "Cool", "cool"): ("Cream Cherry Hoodie",     "Dark Denim Pants"),
    ("School",   "Cool", "cold"): ("Black and White Sweater", "Ripped Jeans"),
    ("Hang out", "Warm", "hot"):  ("Ivory Blouse",            "White Flower Skirt"),
    ("Hang out", "Warm", "warm"): ("Striped Knit Top",        "Beige Shorts"),
    ("Hang out", "Warm", "cool"): ("Brown Denim Jacket",      "Flower Pattern Jeans"),
    ("Hang out", "Warm", "cold"): ("Navy Sweatshirt",         "Camo Pants"),
    ("Hang out", "Cool", "hot"):  ("Yellow Blouse",           "Denim Skirt"),
    ("Hang out", "Cool", "warm"): ("Pink Cardigan",           "Dark Denim Bermuda Shorts"),
    ("Hang out", "Cool", "cool"): ("Blue Cardigan",           "White Denim Pants"),
    ("Hang out", "Cool", "cold"): ("Rainbow Striped Sweater", "Dark Denim Overalls"),
}

class DailyStylingApp:

    def __init__(self, root):
        self.root = root
        self.root.title("Daily Styling")
        self.root.geometry("480x700")
        self.root.resizable(False, False)
        self.root.config(bg=BG)

        self.username_entry = None
        self.weather_entry  = None

        self.scene = ""
        self.tone  = ""
        self.current_top    = ""
        self.current_bottom = ""

        self.image_title         = None
        self.image_my_look       = None
        self.image_closet_btn    = None

        self.image_save_look_btn = None
        self.image_reset_btn     = None
        self.img_top             = None
        self.img_bottom          = None
        self.sfx_click           = None
        self.load_all_images()
        self.play_bgm()
        self.scene_btns = {}
        self.tone_btns  = {}

        self.show_start()

    def play_bgm(self):
        try:
            pygame.mixer.init()
            self.bgm = pygame.mixer.Sound("sounds/dailystyling_bgm.mp3")
            self.bgm.play(loops=-1)
            self.sfx_click = pygame.mixer.Sound("sounds/Click.mp3")
        except Exception as e:
            print("Sound error:", e)

    def play_click_sound(self):
        if self.sfx_click:
            self.sfx_click.play()

    def load_all_images(self):
        try:
            img = Image.open("images/title.jpg")
            img.thumbnail((300, 120))
            self.image_title = ImageTk.PhotoImage(img)

            img = Image.open("images/my_look_btn.jpg")
            img.thumbnail((300, 80))
            self.image_my_look = ImageTk.PhotoImage(img)

            img = Image.open("images/closet_btn.jpg")
            img.thumbnail((80, 40))
            self.image_closet_btn = ImageTk.PhotoImage(img)

            img = Image.open("images/save_look_btn.png")
            img.thumbnail((160, 60))
            self.image_save_look_btn = ImageTk.PhotoImage(img)

            img = Image.open("images/reset_btn.png")
            img.thumbnail((160, 60))
            self.image_reset_btn = ImageTk.PhotoImage(img)

        except Exception as e:
            print("Image error:", e)

    def make_closet_button(self):
        img = self.image_closet_btn
        if img:
            btn = tk.Button(self.root, image=img, bd=0, bg=BG,
                            cursor="hand2", command=None)
        else:
            btn = tk.Button(self.root, text="My Closet",
                            font=("Arial", 10, "bold"),
                            bg=BTN_RED, fg="white", relief="flat",
                            padx=8, pady=4, cursor="hand2",
                            command=None)
        btn.place(x=370, y=14)

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_start(self):
        self.clear_screen()
        self.scene = ""
        self.tone  = ""
        self.scene_btns = {}
        self.tone_btns  = {}

        self.make_closet_button()

        title_img = self.image_title
        tk.Label(self.root, image=title_img, bg=BG).pack(pady=(70, 30))

        frame_name = tk.Frame(self.root, bg=BG)
        frame_name.pack(pady=6)
        tk.Label(frame_name, text="Your Name :",
                 font=("Arial", 12), bg=BG, fg=TEXT_DARK).pack(side="left")
        self.username_entry = tk.Entry(frame_name,
                                       font=("Arial", 12), width=14,
                                       relief="groove", bd=2)
        self.username_entry.insert(0, "user")
        self.username_entry.pack(side="left", padx=6)

        frame_weather = tk.Frame(self.root, bg=BG)
        frame_weather.pack(pady=6)
        tk.Label(frame_weather, text="Temperature (°C) :",
                 font=("Arial", 12), bg=BG, fg=TEXT_DARK).pack(side="left")
        self.weather_entry = tk.Entry(frame_weather,
                                      font=("Arial", 12), width=6,
                                      relief="groove", bd=2)
        self.weather_entry.pack(side="left", padx=6)

        tk.Label(self.root, text="Scene",
                 font=("Arial", 13, "bold"),
                 bg=BG, fg=TEXT_DARK).pack(pady=(20, 5))

        frame_scene = tk.Frame(self.root, bg=BG)
        frame_scene.pack()

        btn_school = tk.Button(frame_scene, text="School",
                               font=("Arial", 11), width=10,
                               relief="groove", cursor="hand2",
                               command=self.on_scene_school)
        btn_school.pack(side="left", padx=5)
        self.scene_btns["School"] = btn_school

        btn_hangout = tk.Button(frame_scene, text="Hang out",
                                font=("Arial", 11), width=10,
                                relief="groove", cursor="hand2",
                                command=self.on_scene_hangout)
        btn_hangout.pack(side="left", padx=5)
        self.scene_btns["Hang out"] = btn_hangout

        tk.Label(self.root, text="Personal Tone",
                 font=("Arial", 13, "bold"),
                 bg=BG, fg=TEXT_DARK).pack(pady=(16, 4))

        frame_tone = tk.Frame(self.root, bg=BG)
        frame_tone.pack()

        btn_warm = tk.Button(frame_tone, text="Warm",
                             font=("Arial", 11), width=10,
                             relief="groove", cursor="hand2",
                             command=self.on_tone_warm)
        btn_warm.pack(side="left", padx=5)
        self.tone_btns["Warm"] = btn_warm

        btn_cool = tk.Button(frame_tone, text="Cool",
                             font=("Arial", 11), width=10,
                             relief="groove", cursor="hand2",
                             command=self.on_tone_cool)
        btn_cool.pack(side="left", padx=5)
        self.tone_btns["Cool"] = btn_cool

        my_look_img = self.image_my_look
        tk.Button(self.root, image=my_look_img, bd=0, bg=BG,
                    cursor="hand2",
                    command=self.on_my_look_click).pack(pady=28)

    def on_my_look_click(self):
        try:
            temp = int(self.weather_entry.get())
        except:
            messagebox.showwarning("Warning", "Temperature out of range.\nPlease check again.")
            return

        if not (-20 <= temp <= 45):
            messagebox.showwarning("Warning", "Temperature out of range.\nPlease check again.")
            return

        if self.scene == "" or self.tone == "":
            messagebox.showwarning("Warning", "Please complete all sections.")
            return

        if temp >= 25:
            temp_cat = "hot"
        elif temp >= 17:
            temp_cat = "warm"
        elif temp >= 9:
            temp_cat = "cool"
        else:
            temp_cat = "cold"
        self.current_top, self.current_bottom = OUTFIT_DATA[(self.scene, self.tone, temp_cat)]

        self.play_click_sound()
        self.show_outfit()

    def on_scene_school(self):
        self.select_scene("School")

    def on_scene_hangout(self):
        self.select_scene("Hang out")

    def on_tone_warm(self):
        self.select_tone("Warm")

    def on_tone_cool(self):
        self.select_tone("Cool")

    def select_scene(self, selected):
        self.scene = selected
        for name, btn in self.scene_btns.items():
            if name == selected:
                btn.config(bg=ACCENT, fg="white", relief="sunken")
            else:
                btn.config(bg="SystemButtonFace", fg="black", relief="groove")

    def select_tone(self, selected):
        self.tone = selected
        for name, btn in self.tone_btns.items():
            if name == selected:
                btn.config(bg=ACCENT, fg="white", relief="sunken")
            else:
                btn.config(bg="SystemButtonFace", fg="black", relief="groove")

    def on_save_look(self):
        messagebox.showinfo("Saved!", f"Your look has been saved!\n\nTOP : {self.current_top}\nBOTTOM : {self.current_bottom}")

    def show_outfit(self):
        name = self.username_entry.get().strip() or "user"
        self.clear_screen()

        self.make_closet_button()
        tk.Label(self.root, text=f"{name}'s OOTD",
                 font=("Georgia", 24, "bold"),
                 bg=BG, fg=TEXT_DARK).pack(pady=(52, 18))

        frame_outfit = tk.Frame(self.root, bg=BG)
        frame_outfit.pack(pady=6)

        tk.Label(frame_outfit, text="TOP",
                 font=("Arial", 11, "bold"),
                 bg=BG, fg=TEXT_GRAY).grid(row=0, column=0, padx=24)
        tk.Label(frame_outfit, text="BOTTOM",
                 font=("Arial", 11, "bold"),
                 bg=BG, fg=TEXT_GRAY).grid(row=0, column=1, padx=24)

        try:
            img_t = Image.open(f"images/{self.current_top.lower()}.png")
            img_t.thumbnail((160, 190))
            self.img_top = ImageTk.PhotoImage(img_t)
            tk.Label(frame_outfit, image=self.img_top, bg=BG,
                     width=160, height=192, relief="groove").grid(row=1, column=0, padx=24, pady=8)
        except Exception:
            tk.Label(frame_outfit, text=self.current_top,
                     font=("Arial", 11), bg=BG, fg=TEXT_DARK,
                     width=16, height=9, relief="groove").grid(row=1, column=0, padx=24, pady=8)

        try:
            img_b = Image.open(f"images/{self.current_bottom.lower()}.png")
            img_b.thumbnail((160, 190))
            self.img_bottom = ImageTk.PhotoImage(img_b)
            tk.Label(frame_outfit, image=self.img_bottom, bg=BG,
                     width=160, height=192, relief="groove").grid(row=1, column=1, padx=24, pady=8)
        except Exception:
            tk.Label(frame_outfit, text=self.current_bottom,
                     font=("Arial", 11), bg=BG, fg=TEXT_DARK,
                     width=16, height=9, relief="groove").grid(row=1, column=1, padx=24, pady=8)

        tk.Label(self.root,
                 text=f"{self.current_top}  &  {self.current_bottom}",
                 font=("Arial", 12, "italic"),
                 bg=BG, fg=TEXT_MID).pack(pady=10)

        btn_frame = tk.Frame(self.root, bg=BG)
        btn_frame.pack(pady=22)

        tk.Button(btn_frame, image=self.image_save_look_btn, bd=0, bg=BG, cursor="hand2",
                      command=self.on_save_look).pack(side="left", padx=10)

        tk.Button(btn_frame, image=self.image_reset_btn, bd=0, bg=BG, cursor="hand2",
                      command=self.show_start).pack(side="left", padx=10)


if __name__ == "__main__":
    root = tk.Tk()
    app = DailyStylingApp(root)
    root.mainloop()
